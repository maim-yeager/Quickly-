package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.navigation.QuickDropNavGraph
import com.example.ui.theme.GlassDarkBackground
import com.example.ui.theme.QuickDropTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            QuickDropTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = GlassDarkBackground
                ) {
                    QuickDropNavGraph()
                }
            }
        }
    }
}
